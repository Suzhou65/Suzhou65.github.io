EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L NT3H1101:NT3H1101 U1
U 1 1 5EDE4D10
P 5600 3600
F 0 "U1" H 5600 4115 50  0000 C CNN
F 1 "NT3H1101" H 5600 4024 50  0000 C CNN
F 2 "NT3H1101:SOP65P490X110-8N" H 5600 3600 50  0001 C CNN
F 3 "DOCUMENTATION" H 5600 3600 50  0001 C CNN
	1    5600 3600
	1    0    0    -1  
$EndComp
$Comp
L Device:C C1
U 1 1 5EDE58D7
P 4400 3600
F 0 "C1" H 4515 3646 50  0000 L CNN
F 1 "C" H 4515 3555 50  0000 L CNN
F 2 "Capacitor_SMD:C_0603_1608Metric" H 4438 3450 50  0001 C CNN
F 3 "~" H 4400 3600 50  0001 C CNN
	1    4400 3600
	1    0    0    -1  
$EndComp
$Comp
L Device:R R1
U 1 1 5EDE6B02
P 3850 3300
F 0 "R1" H 3920 3346 50  0000 L CNN
F 1 "47" H 3920 3255 50  0000 L CNN
F 2 "Resistor_SMD:R_0603_1608Metric" V 3780 3300 50  0001 C CNN
F 3 "~" H 3850 3300 50  0001 C CNN
	1    3850 3300
	1    0    0    -1  
$EndComp
$Comp
L Device:LED D1
U 1 1 5EDE7388
P 3850 3900
F 0 "D1" V 3889 3783 50  0000 R CNN
F 1 "LED" V 3798 3783 50  0000 R CNN
F 2 "LED_SMD:LED_0805_2012Metric" H 3850 3900 50  0001 C CNN
F 3 "~" H 3850 3900 50  0001 C CNN
	1    3850 3900
	0    -1   -1   0   
$EndComp
Wire Wire Line
	3850 3450 3850 3750
Wire Wire Line
	3850 4050 3850 4300
Wire Wire Line
	3850 4300 4400 4300
Wire Wire Line
	4400 4300 4400 3750
Wire Wire Line
	4400 4300 4750 4300
Wire Wire Line
	4750 4300 4750 3550
Wire Wire Line
	4750 3550 4850 3550
Connection ~ 4400 4300
Wire Wire Line
	6350 3550 6550 3550
Wire Wire Line
	6550 3650 6350 3650
Wire Wire Line
	6550 2850 4400 2850
Wire Wire Line
	3850 2850 3850 3150
Wire Wire Line
	6550 2850 6550 3550
Connection ~ 6550 3550
Wire Wire Line
	6550 3550 6550 3650
Wire Wire Line
	4400 3450 4400 2850
Connection ~ 4400 2850
Wire Wire Line
	4400 2850 3850 2850
$Comp
L Device:Antenna_Dipole AE1
U 1 1 5EDE9B44
P 6900 3750
F 0 "AE1" V 6904 3730 50  0000 L CNN
F 1 "Antenna_Dipole" V 6995 3730 50  0000 L CNN
F 2 "RF_Antenna:Antenna_NFC" H 6900 3750 50  0001 C CNN
F 3 "~" H 6900 3750 50  0001 C CNN
	1    6900 3750
	0    1    1    0   
$EndComp
Wire Wire Line
	6350 3750 6700 3750
Wire Wire Line
	6700 3850 6150 3850
Wire Wire Line
	6150 3850 6150 4050
Wire Wire Line
	6150 4050 4650 4050
Wire Wire Line
	4650 4050 4650 3450
Wire Wire Line
	4650 3450 4850 3450
$Comp
L Device:Antenna_Dipole AE2
U 1 1 5EDEBD21
P 6750 4700
F 0 "AE2" H 6980 4614 50  0000 L CNN
F 1 "Antenna_Dipole" H 6980 4523 50  0000 L CNN
F 2 "RF_Antenna:Antenna_RFID" H 6750 4700 50  0001 C CNN
F 3 "~" H 6750 4700 50  0001 C CNN
	1    6750 4700
	1    0    0    -1  
$EndComp
Wire Wire Line
	6100 4950 6100 5050
Wire Wire Line
	6100 5050 6750 5050
Wire Wire Line
	6750 5050 6750 4900
Wire Wire Line
	6850 4900 6850 5050
Wire Wire Line
	6850 5050 7750 5050
Wire Wire Line
	7750 5050 7750 4950
NoConn ~ 4850 3650
NoConn ~ 4850 3750
NoConn ~ 6350 3450
$Comp
L Connector:TestPoint TP1
U 1 1 5EECD1ED
P 6100 4950
F 0 "TP1" H 6158 5068 50  0000 L CNN
F 1 "TestPoint" H 6158 4977 50  0000 L CNN
F 2 "TestPoint:TestPoint_Pad_D1.5mm" H 6300 4950 50  0001 C CNN
F 3 "~" H 6300 4950 50  0001 C CNN
	1    6100 4950
	1    0    0    -1  
$EndComp
$Comp
L Connector:TestPoint TP2
U 1 1 5EECD7B2
P 7750 4950
F 0 "TP2" H 7808 5068 50  0000 L CNN
F 1 "TestPoint" H 7808 4977 50  0000 L CNN
F 2 "TestPoint:TestPoint_Pad_D1.5mm" H 7950 4950 50  0001 C CNN
F 3 "~" H 7950 4950 50  0001 C CNN
	1    7750 4950
	1    0    0    -1  
$EndComp
$EndSCHEMATC
